package ${IJ_BASE_PACKAGE}.game;

import com.badlogic.gdx.Files;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

import javax.swing.*;
import java.awt.*;
import java.io.*;

public class Main {
    static BufferedWriter writer;

    public static final String GAME_NAME = "";

    public static void main(String[] args){
        Frame frame = new Frame();
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("log.txt"), "utf-8"));
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Well even the log writer failed - please look at the console for stack trace!");
        }finally {
            try{ writer.close();}catch (Exception i){System.exit(-1);}
        }

        for (String arg : args) {
            if (arg.equals("-s")) {
                //start server
                break;
            } else if (arg.equals("-d")) {
                //debug
                break;
            } else if (arg.equals("-v")) {
                //verbose (log everything)
                break;
            }
        }
        try{
            LwjglApplicationConfiguration cfg = new LwjglApplicationConfiguration();
            cfg.title = GAME_NAME;
            cfg.useGL20 = true;
            cfg.width = 1024;
            cfg.height = 768;
            cfg.addIcon("Assets/Icons/icon.png", Files.FileType.Internal);
            new LwjglApplication(new Game(), cfg);
            System.out.println("Game initialized correctly");
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Whoops something went wrong, please report the log file!");
            try{
                writer.write("Error: "+e.getMessage());
            }catch (IOException i){
                i.printStackTrace();
                JOptionPane.showMessageDialog(frame, "Well, writer failed, please look at the console for stack trace!");
            }
        }finally {
            try{ writer.close();}catch (Exception i){System.exit(-1);}
        }
    }
}
