package ${IJ_BASE_PACKAGE}.game;


import ${IJ_BASE_PACKAGE}.screens.Splash;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class Game extends com.badlogic.gdx.Game{
    Frame frame;
    BufferedWriter writer;
    @Override
    public void create() {
        frame = new Frame();
        try {
            writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("log.txt"), "utf-8"));
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Even the log writer failed! Stack Trace in console!");
        }finally{
            try{writer.close();}catch (Exception e){e.printStackTrace();}
        }
        try{
            setScreen(new Splash(this));
        }catch(Exception e){
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Whoops something went wrong please report the log!");
            try {
                writer.write("");
            }catch(Exception i){
                i.printStackTrace();
            }finally{
                try{writer.close();}catch (Exception i){i.printStackTrace();}
            }
        }finally{
            try{writer.close();}catch (Exception e){e.printStackTrace();}
        }
    }
}
